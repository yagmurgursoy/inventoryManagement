package com.warehouse.solutions.inventorymanagement.controller;

import com.warehouse.solutions.inventorymanagement.model.Article;
import com.warehouse.solutions.inventorymanagement.model.Product;
import com.warehouse.solutions.inventorymanagement.model.ProductRequiredInventory;
import com.warehouse.solutions.inventorymanagement.service.ArticleService;

import com.warehouse.solutions.inventorymanagement.service.ProductService;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/article")
public class ArticleController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ArticleController.class);

    @Autowired
    ArticleService articleService;

    @Autowired
    ProductService productService;

    @GetMapping("/uploadInventory")
    public void uploadInventory() {

        try {
            JSONParser parser = new JSONParser();

            String file ="src/main/resources/inventory.json";
            Object obj = parser.parse(new FileReader(file));
            JSONObject jsonObject=(JSONObject) obj;
            JSONArray inventoryList = (JSONArray) jsonObject.get("inventory");
            List<Article> articleList= new ArrayList<>();
            for (Object o : inventoryList) {
                Article article = new Article();
                JSONObject inventory = (JSONObject) o;

                String name = (String) inventory.get("name");
                article.setName(name);

                Integer stock = Integer.valueOf((String) inventory.get("stock"));
                article.setStock(stock);

                Long artId = Long.valueOf((String) inventory.get("art_id"));
                article.setArtId(artId);

                articleList.add(article);
            }
            articleService.uploadArticles(articleList);
        } catch (Exception e) {
            LOGGER.error("An error occurred while getting invertory : " + e.getMessage());
        }
    }

    @GetMapping(value ="/sellProduct/{id}")
    public void removeProduct(
            @PathVariable Long id) throws Exception {
        try {
        Optional<Product> productById = productService.getProductById(id);
        if(productById == null)
            throw new Exception("There is no product with this id.");
        List<ProductRequiredInventory> productArticleRequirements = productById.get().getArticleRequirements();
        List<Optional<Article>> articleList= new ArrayList<>();
        for(ProductRequiredInventory productRequiredInventory:productArticleRequirements){
            Optional<Article> article = articleService.getById(productRequiredInventory.getArticle().getArtId());
            article.get().setStock(article.get().getStock()-productRequiredInventory.getAmount());
            articleList.add(article);
        }

        List<Article> finalArticleList = articleList.stream()
                .flatMap(Optional::stream)
                .collect(Collectors.toList());

        articleService.uploadArticles(finalArticleList);
        } catch (Exception e) {
            LOGGER.error("An error occurred while removing product : " + e.getMessage());
        }
    }

}
