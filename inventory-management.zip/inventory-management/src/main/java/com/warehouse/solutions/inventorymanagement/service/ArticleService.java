package com.warehouse.solutions.inventorymanagement.service;

import com.warehouse.solutions.inventorymanagement.model.Article;
import com.warehouse.solutions.inventorymanagement.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Service;

import javax.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

@Service
public class ArticleService {

    @Autowired
    private ArticleRepository articleRepository;

    public List<Article> getAllArticles() {
        return (List<Article>) articleRepository.findAll();
    }

    public void uploadArticles(List<Article> articles) {
         articleRepository.saveAll(articles);
    }

    @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
    public Optional<Article> getById(Long id){
      return   articleRepository.findById(id);
    }

}
