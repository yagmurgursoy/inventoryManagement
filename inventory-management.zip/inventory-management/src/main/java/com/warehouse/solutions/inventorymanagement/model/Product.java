package com.warehouse.solutions.inventorymanagement.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "PRODUCT" ,uniqueConstraints=
@UniqueConstraint(columnNames = { "NAME"}))
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "PRODUCT_ID", unique=true, nullable=false)
    private Long id;


    @Column(name = "NAME",columnDefinition = "nvarchar(256)",nullable=false)
    private String name;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "product")
    private List<ProductRequiredInventory> articleRequirements = new ArrayList<>();

}
