package com.warehouse.solutions.inventorymanagement.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@Table(name = "ARTICLE" ,uniqueConstraints=
@UniqueConstraint(columnNames = { "NAME"}))
public class Article {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ART_ID", unique=true, nullable=false)
    private Long artId;

    @Column(name = "NAME",columnDefinition = "nvarchar(256)")
    private String name;

    @Column(name = "STOCK")
    private Integer stock;


    @Version
    private Integer version;


    public Article() {

    }
}
