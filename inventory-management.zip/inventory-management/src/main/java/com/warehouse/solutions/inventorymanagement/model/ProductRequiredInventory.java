package com.warehouse.solutions.inventorymanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Setter
@Getter
@Table(name = "PRODUCT_REQUIRED_INVENTORY" )
public class ProductRequiredInventory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @JsonIgnore
    @ManyToOne(targetEntity = Article.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "ART_ID")
    private Article article;

    @Column(name = "AMOUNT")
    private Integer amount;

    @JsonIgnore
    @ManyToOne(targetEntity = Product.class)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private Product product;
}
