package com.warehouse.solutions.inventorymanagement.controller;

import com.warehouse.solutions.inventorymanagement.model.Article;
import com.warehouse.solutions.inventorymanagement.model.Product;
import com.warehouse.solutions.inventorymanagement.model.ProductRequiredInventory;
import com.warehouse.solutions.inventorymanagement.service.ArticleService;
import com.warehouse.solutions.inventorymanagement.service.ProductService;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.FileReader;
import java.util.*;

@RestController
@RequestMapping("/product")
public class ProductController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    ProductService productService;

    @Autowired
    ArticleService articleService;

    @GetMapping("/uploadProductRequirements")
    public void uploadProducts() {

        try {
            JSONParser parser = new JSONParser();
            String file ="src/main/resources/products.json";
            Object obj = parser.parse(new FileReader(file));
            JSONObject jsonObject=(JSONObject) obj;
            JSONArray productRequiredList = (JSONArray) jsonObject.get("products");
            List<Product> productList= new ArrayList<>();
            for (Object o : productRequiredList) {
                Product product = new Product();
                JSONObject productRequirement = (JSONObject) o;

                String name = (String) productRequirement.get("name");
                product.setName(name);

                JSONObject jsonObject1=(JSONObject) o;
                JSONArray containArticles = (JSONArray) jsonObject1.get("contain_articles");
                List<ProductRequiredInventory> articleRequirements = new ArrayList<>();
             for(Object art :containArticles ){
                 JSONObject productArt = (JSONObject) art;
                 ProductRequiredInventory productRequiredInventory = new  ProductRequiredInventory();
                 productRequiredInventory.setProduct(product);
                 productRequiredInventory.setAmount( Integer.valueOf((String) productArt.get("amount_of")));
                 Optional<Article> article= articleService.getById(Long.valueOf((String) productArt.get("art_id")));
                 productRequiredInventory.setArticle(article.get());
                 articleRequirements.add(productRequiredInventory);
             }

             product.setArticleRequirements(articleRequirements);
             productList.add(product);
            }
           productService.uploadProducts(productList);
        } catch (Exception e) {
            LOGGER.error("An error occurred while getting product articles : " + e.getMessage());
        }
    }


    @GetMapping("/allPossibleProducts")
    public String getAllPossibleProducts() {
        try {
        List<Product> allProducts = productService.getAllProducts();
        List<Article> allArticles = articleService.getAllArticles();

        String result="";
        for(Product product:allProducts) {
            HashSet<Integer> set = new HashSet<>();
            for( ProductRequiredInventory productRequiredInventory:product.getArticleRequirements()) {
                Article article = allArticles.stream().filter(o -> o.getArtId().equals(productRequiredInventory.getArticle().getArtId())).findFirst().orElse(null);
                if(article != null){
                    set.add(article.getStock()/productRequiredInventory.getAmount());
                }
            }
            result =result + product.getName() +" :"+  Collections.min(set) +" quantity. ";
        }
         return result;
        } catch (Exception e) {
            LOGGER.error("An error occurred while getting product articles : " + e.getMessage());
        }
        return null;
    }



}
